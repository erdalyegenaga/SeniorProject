/* USER CODE BEGIN Header */

/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/

#include "usb_host.h"
#include "usbh_core.h"
#include "usbh_audio.h"
#include "usbh_MIDI.h"
#include "adsr.h"
#include "stm32f4_discovery.h"
#include "sinetable.h"
/* USER CODE BEGIN Includes */
extern UART_HandleTypeDef huart2;
/* USER CODE END Includes */

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/

/* USER CODE END PV */
/* Private define ------------------------------------------------------------*/
#define MAX_SCALE_INDEX		14	/* starting at 0  */
#define LOWEST_NOTE			21  /* 21 is MIDI note number for A0 */
#define MAX_NOTE_INDEX		106	/* starting at 0  */
#define RX_BUFF_SIZE 64

uint8_t MIDI_RX_Buffer[RX_BUFF_SIZE];
int8_t currentNote;
int8_t velocity;
uint8_t notes_On[128] = {0};
int8_t notesCount = 0;
/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* USB Host core handle declaration */
USBH_HandleTypeDef hUsbHostFS;
ApplicationTypeDef Appli_state = APPLICATION_IDLE;

/*
 * -- Insert your variables declaration here --
 */
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/*
 * user callback declaration
 */
static void USBH_UserProcess(USBH_HandleTypeDef *phost, uint8_t id);

/*
 * -- Insert your external function declaration here --
 */
/* USER CODE BEGIN 1 */

/* USER CODE END 1 */

/**
  * Init USB host library, add supported class and start the library
  * @retval None
  */
void MX_USB_HOST_Init(void)
{
  /* USER CODE BEGIN USB_HOST_Init_PreTreatment */

  /* USER CODE END USB_HOST_Init_PreTreatment */

  /* Init host Library, add supported class and start the library. */
  if (USBH_Init(&hUsbHostFS, USBH_UserProcess, HOST_FS) != USBH_OK)
  {
    Error_Handler();
  }
  if (USBH_RegisterClass(&hUsbHostFS, USBH_MIDI_CLASS) != USBH_OK)
  {
    Error_Handler();
  }
  if (USBH_Start(&hUsbHostFS) != USBH_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USB_HOST_Init_PostTreatment */

  /* USER CODE END USB_HOST_Init_PostTreatment */
}


/*
 * Background task
 */
void MX_USB_HOST_Process(void)
{
  /* USB Host Background task */
  USBH_Process(&hUsbHostFS);
}
/*
 * user callback definition
 */
char Uart_Buf[100];
int lenn=10;
static void USBH_UserProcess  (USBH_HandleTypeDef *phost, uint8_t id)
{
  /* USER CODE BEGIN CALL_BACK_1 */
  switch(id)
  {
  case HOST_USER_SELECT_CONFIGURATION:
  break;

  case HOST_USER_DISCONNECTION:
  Appli_state = APPLICATION_DISCONNECT;
  lenn = sprintf (Uart_Buf, "disconnect");
  			HAL_UART_Transmit(&huart2, (uint8_t *) Uart_Buf, lenn, 100);
  break;

  case HOST_USER_CLASS_ACTIVE:
  Appli_state = APPLICATION_READY;
  USBH_MIDI_Receive(&hUsbHostFS, MIDI_RX_Buffer, RX_BUFF_SIZE); // just once at the beginning, start the first reception
  lenn = sprintf (Uart_Buf, "ready");
  HAL_UART_Transmit(&huart2, (uint8_t *) Uart_Buf, lenn, 100);
  break;

  case HOST_USER_CONNECTION:
  Appli_state = APPLICATION_START;
  lenn = sprintf (Uart_Buf, "start");
   			HAL_UART_Transmit(&huart2, (uint8_t *) Uart_Buf, lenn, 100);
  break;

  default:
  break;
  }
  /* USER CODE END CALL_BACK_1 */
}
void Reset_notes_On(void)
{
	notesCount = 0;
	for (uint8_t i = 0; i < 128; i++)
		notes_On[i] = 0;
}

/*-----------------------------------------------------------------------------*/
void ProcessReceivedMidiDatas(void)
{
	uint16_t numberOfPackets;
	uint8_t *ptr = MIDI_RX_Buffer;
	midi_package_t pack;

	//	if (notesCount < 0) {
	//		BSP_LED_On(LED_Red);
	//	} else {
	//		BSP_LED_Off(LED_Red);
	//	}

	numberOfPackets = USBH_MIDI_GetLastReceivedDataSize(&hUsbHostFS) / 4; //each USB midi package is 4 bytes long

	while (numberOfPackets--)
	{
		pack.cin_cable = *ptr;
		ptr++;
		pack.evnt0 = *ptr;
		ptr++;
		pack.evnt1 = *ptr;
		ptr++;
		pack.evnt2 = *ptr;
		ptr++;

		if (pack.cin_cable != 0) // if incoming midi message...
		{}



			if ((pack.evnt0 & 0xF0) == 0x80) // Note off ? -------------------------------
			{

				 lenn = sprintf (Uart_Buf, "OFF");
				  			HAL_UART_Transmit(&huart2, (uint8_t *) Uart_Buf, lenn, 100);
				uint8_t noteOff = pack.evnt1;
				//if (notes_On[noteOff] == 1) {
				notes_On[noteOff] = 0;
				notesCount--;
				if (notesCount <= 0) // no more keys pressed
				{

					notesCount = 0;
				}
				else // some keys still pressed... (legato)
				{
					if ((noteOff - LOWEST_NOTE) == currentNote) // then let sound the lowest key pressed
					{
						uint8_t i;
						for (i = 0; i < 128; i++)
						{
							if (notes_On[i] == 1) // find the lowest key pressed
								break;
						}
						currentNote = i - LOWEST_NOTE; // conversion for notesFreq[]
					}
				}
				//}
			}
			else if ((pack.evnt0 & 0xF0) == 0x90) // Note on ----------------------------
			{

				uint8_t noteOn = pack.evnt1;
				velocity = pack.evnt2;
				if (velocity > 0) // True note on !
				{
					if (noteOn < LOWEST_NOTE) // filtering notes
					{
						currentNote = 0;
					}
					else
					{
						currentNote = noteOn - LOWEST_NOTE; // conversion for notesFreq[]
						 lenn = sprintf (Uart_Buf, "%d",currentNote);
						HAL_UART_Transmit(&huart2, (uint8_t *) Uart_Buf, lenn, 100);
					}
					// if (notesCount <= 0) // if just one key pressed
					// {
					// 	ADSR_keyOn(&adsr);
					// 	notesCount = 0;
					// }

					notesCount++;
					notes_On[noteOn] = 1;
				}
				else
				{
					// ---------  Sometimes Note On with zero velocity means Note Off !
					notes_On[noteOn] = 0;
					notesCount--;
					if (notesCount <= 0)
					{

						notesCount = 0;
					}
					else
					{
						if ((noteOn - LOWEST_NOTE) == currentNote)
						{
							uint8_t i;
							for (i = 0; i < 128; i++)
							{
								if (notes_On[i] == 1) // find the lowest key pressed
									break;
							}
							currentNote = i - LOWEST_NOTE; // conversion for notesFreq[]
						}
					}
				}
			}
			else if ((pack.evnt0 & 0xF0) == 0xA0) // Aftertouch
			{
				// Filter1Res_set(pack.evnt2);
			}
			else if ((pack.evnt0 & 0xF0) == 0xE0) // Pitch Bend
			{
				// int16_t pitchBend = ((pack.evnt1 << 7) + pack.evnt2) - 0x2000;
			}


		/*------------------------------------------------------------------------------------------*/

		if ((pack.evnt0 & 0xF0) == 0xB0) /* If incoming midi message is a Control Change... */
		{
			uint8_t val = pack.evnt2;

			switch (pack.evnt1) // CC number
			{
			case 1:
				AttTime_set(val);
				break; // modulation wheel
			case 3:
				DecTime_set(val);
				break; // tempo
			case 13:
				SustLevel_set(val);
				break; // master volume
			case 31:
				RelTime_set(val);
				break; // toggle synth output

			}
		}
	}
}
void USBH_MIDI_ReceiveCallback(USBH_HandleTypeDef *phost)
{

	ProcessReceivedMidiDatas();
	USBH_MIDI_Receive(&hUsbHostFS, MIDI_RX_Buffer, RX_BUFF_SIZE); // start a new reception
}

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
